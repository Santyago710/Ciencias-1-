package arbol;

public class ArbolBinario {
    NodoArbol raiz;

    public ArbolBinario() {
        raiz = null;
    }

    // Método para insertar nodo en el árbol
    public void agregar(int val, String nom) {
        NodoArbol nuevo = new NodoArbol(val, nom);
        if (raiz == null) {
            raiz = nuevo;
        } else {
            NodoArbol auxiliar = raiz;
            NodoArbol padre;
            while (true) {
                padre = auxiliar;
                if (val < auxiliar.valor) {
                    auxiliar = auxiliar.nodoIzq;
                    if (auxiliar == null) {
                        padre.nodoIzq = nuevo;
                        return;
                    }
                } else {
                    auxiliar = auxiliar.nodoDer;
                    if (auxiliar == null) {
                        padre.nodoDer = nuevo;
                        return;
                    }
                }
            }
        }
    }

    public boolean estaVacio() {
        return raiz == null;
    }

    public NodoArbol getRaiz() {
        return raiz;
    }
}
