package arbol;
public class Main {

	public static void main(String[] args) {
        ArbolBinario arbol = new ArbolBinario();
        arbol.agregar(10, "Raíz");
        arbol.agregar(5, "Izquierdo");
        arbol.agregar(15, "Derecho");

        VerificadorArbol verificador = new VerificadorArbol(arbol);
        System.out.println(verificador.tipoDeArbol());
    }

}